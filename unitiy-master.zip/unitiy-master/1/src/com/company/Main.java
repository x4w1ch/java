package com.company;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Tasks.Task_1 t1 = new Tasks.Task_1();
        Tasks.Task_2 t2 = new Tasks.Task_2();
        t1.answer();
        t2.answer();
    }
}
